# ReiikuID

Template katalog aplikasi Android statis menggunakan HTML, CSS, dan JavaScript.

## Isi
- `index.html` — struktur halaman
- `style.css` — desain responsif
- `script.js` — data katalog, pencarian, kategori, dan detail aplikasi

## Menjalankan secara lokal
1. Ekstrak folder `ReiikuID`.
2. Buka `index.html` di browser, atau jalankan Live Server dari VS Code.

## Mengubah daftar aplikasi
Buka `script.js`, lalu edit array `apps`. Setiap item memiliki:
- `name`, `category`, `version`, `size`, `updated`
- `symbol`, `color`, `description`
- `downloadUrl`

Isi `downloadUrl` dengan URL HTTPS file APK yang memang kamu miliki atau berhak distribusikan. Jika kosong, tombol unduh akan tampil sebagai "File belum tersedia". Contoh:
`downloadUrl: "https://domain-kamu.com/files/aplikasi-resmi.apk"`

Jangan menautkan APK bajakan, aplikasi hasil modifikasi tanpa izin, atau file yang sumber dan keamanannya tidak jelas. Periksa hak distribusi dan keamanan file sebelum dipublikasikan.

## Deploy ke Vercel
1. Buat akun di https://vercel.com jika belum punya.
2. Buat repository GitHub baru, misalnya `reiikuid`.
3. Upload tiga file (`index.html`, `style.css`, `script.js`) ke root repository.
4. Di Vercel pilih **Add New → Project**, lalu import repository tersebut.
5. Framework Preset pilih **Other**. Build Command dan Output Directory dapat dikosongkan; Root Directory `./`.
6. Klik **Deploy**. Vercel akan memberikan alamat seperti `reiikuid.vercel.app`.

## Menggunakan domain reiikuid.vercel.app
Nama subdomain `reiikuid.vercel.app` hanya bisa dipakai jika masih tersedia dan dapat ditambahkan di pengaturan proyek Vercel. Buka **Project → Settings → Domains**, masukkan `reiikuid.vercel.app`, lalu ikuti instruksi verifikasi yang ditampilkan Vercel.

## Catatan
Ini frontend statis, belum memiliki login/admin panel atau fitur upload file. Untuk memperbarui katalog, edit `script.js` lalu deploy ulang. Jangan pernah menyimpan kata sandi atau kredensial rahasia di file JavaScript publik.
