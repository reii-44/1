// Ganti data contoh di bawah dengan aplikasi yang kamu miliki atau berhak distribusikan.
const apps = [
  {id:1,name:"Reiiku Tools",category:"Aplikasi",version:"1.0.0",size:"8 MB",updated:"23 Nov 2026",symbol:"R",color:"#6957e8",description:"Aplikasi utilitas contoh untuk melengkapi katalog ReiikuID.",downloadUrl:"",status:"Segera hadir"},
  {id:2,name:"Pixel Notes",category:"Aplikasi",version:"2.1.0",size:"12 MB",updated:"20 Nov 2026",symbol:"✎",color:"#16a085",description:"Catatan sederhana dengan tampilan bersih dan mudah digunakan.",downloadUrl:"",status:"Segera hadir"},
  {id:3,name:"Sky Adventure",category:"Game",version:"1.4.2",size:"95 MB",updated:"18 Nov 2026",symbol:"✦",color:"#e79a36",description:"Contoh kartu game petualangan. Ganti dengan deskripsi game milikmu.",downloadUrl:"",status:"Segera hadir"},
  {id:4,name:"Music Space",category:"Aplikasi",version:"3.0.1",size:"24 MB",updated:"15 Nov 2026",symbol:"♫",color:"#d85b83",description:"Contoh aplikasi pemutar audio untuk demonstrasi katalog.",downloadUrl:"",status:"Segera hadir"},
  {id:5,name:"Block Puzzle",category:"Game",version:"1.2.0",size:"32 MB",updated:"12 Nov 2026",symbol:"▦",color:"#3983c9",description:"Game puzzle kasual contoh dengan tantangan ringan.",downloadUrl:"",status:"Segera hadir"},
  {id:6,name:"File Manager",category:"Aplikasi",version:"1.8.0",size:"16 MB",updated:"10 Nov 2026",symbol:"▰",color:"#737b8e",description:"Contoh pengelola file untuk mengisi tampilan katalog.",downloadUrl:"",status:"Segera hadir"}
];

let activeCategory = "Semua";
const grid = document.getElementById("appGrid");
const search = document.getElementById("searchInput");
const count = document.getElementById("resultCount");
const empty = document.getElementById("emptyState");
const dialog = document.getElementById("appDialog");

function renderApps(){
  const term = search.value.trim().toLowerCase();
  const filtered = apps.filter(app =>
    (activeCategory === "Semua" || app.category === activeCategory) &&
    (app.name.toLowerCase().includes(term) || app.description.toLowerCase().includes(term))
  );
  count.textContent = `${filtered.length} aplikasi`;
  empty.hidden = filtered.length !== 0;
  grid.innerHTML = filtered.map(app => `
    <article class="app-card" data-id="${app.id}" tabindex="0" role="button" aria-label="Detail ${escapeHTML(app.name)}">
      <div class="app-top">
        <div class="app-icon" style="background:${app.color}">${escapeHTML(app.symbol)}</div>
        <div class="app-info"><h3>${escapeHTML(app.name)}</h3><p>${escapeHTML(app.category)} · v${escapeHTML(app.version)}</p></div>
      </div>
      <p class="app-desc">${escapeHTML(app.description)}</p>
      <div class="app-bottom"><span class="app-meta">${escapeHTML(app.size)} · ${escapeHTML(app.updated)}</span><span class="detail-link">DETAIL ↗</span></div>
    </article>`).join("");
  grid.querySelectorAll(".app-card").forEach(card => {
    card.addEventListener("click", () => showDetails(Number(card.dataset.id)));
    card.addEventListener("keydown", e => { if(e.key === "Enter" || e.key === " "){e.preventDefault();showDetails(Number(card.dataset.id));} });
  });
}
function escapeHTML(value){
  return String(value).replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function showDetails(id){
  const app = apps.find(item => item.id === id);
  if(!app) return;
  const hasDownload = Boolean(app.downloadUrl && /^https?:\/\//i.test(app.downloadUrl));
  document.getElementById("dialogContent").innerHTML = `
    <div class="dialog-app-icon" style="background:${app.color}">${escapeHTML(app.symbol)}</div>
    <h2>${escapeHTML(app.name)}</h2><div class="dialog-sub">${escapeHTML(app.category)} · Versi ${escapeHTML(app.version)}</div>
    <p class="dialog-description">${escapeHTML(app.description)}</p>
    <div class="detail-row"><span>Ukuran</span><strong>${escapeHTML(app.size)}</strong></div>
    <div class="detail-row"><span>Terakhir diperbarui</span><strong>${escapeHTML(app.updated)}</strong></div>
    <div class="detail-row"><span>Status</span><strong>${hasDownload ? "Tersedia" : "Belum tersedia"}</strong></div>
    ${hasDownload ? `<a class="download-btn" href="${escapeHTML(app.downloadUrl)}" target="_blank" rel="noopener noreferrer">Unduh aplikasi ↗</a>` : `<span class="download-btn disabled">File belum tersedia</span>`}`;
  dialog.showModal();
}
document.getElementById("filters").addEventListener("click", event => {
  const button = event.target.closest("button[data-category]");
  if(!button) return;
  activeCategory = button.dataset.category;
  document.querySelectorAll(".filter").forEach(item => item.classList.toggle("active", item === button));
  renderApps();
});
search.addEventListener("input", renderApps);
document.getElementById("closeDialog").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => { if(event.target === dialog) dialog.close(); });
document.getElementById("year").textContent = new Date().getFullYear();
document.getElementById("menuBtn").addEventListener("click", () => document.querySelector("nav").classList.toggle("open"));
renderApps();
